import spamEr.__main__
